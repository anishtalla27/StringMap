StringMap hosted recognizer corresponding source
HOMR revision 457e7c6518a10ba755db2e60883419e56c4d7369; its complete source, training and model-export code are in HOMR-upstream.tar.gz.
The guitar adapter and all service build scripts are included here. No recognition engine is embedded in the iOS app.
Install Python 3.12, pip install -r requirements-lock.txt, then python patch_homr.py and python models.py --download.
patch_homr.py verifies the pinned upstream XML writer, preserves its exact rational timing grid and emits every simultaneous rest.
symbol_timing.py preserves interleaved onsets while earlier rhythmic voices sustain.
The checksum-verified CPU model weights are obtained from the upstream release URLs in models.py.
For a local run: OMR_ENV=development OMR_DATA_DIR=/tmp/stringmap uvicorn production:configured_app --factory --host 127.0.0.1.
Production requires Apple App Attest configuration as described in production.py and deployment authentication setup.
